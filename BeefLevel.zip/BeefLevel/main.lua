-- name: Construction
-- description: loony lunchly

smlua_text_utils_course_acts_replace(COURSE_WF, (" 1 CONSTRUCTION CALAMITY"),    ("SHOOT TO KING WHOMP'S CASTLE"),    ("CLIMB THE MOUND"),    ("OVER THE CRANES"),    ("SHOOT TO THE WORK IN PROGRESS CASTLE"),    ("STAR NAME"),    ("STAR NAME"))

local starPositions = gLevelValues.starPositions
vec3f_set(starPositions.KingWhompStarPos, -5116, -5006, -5381)