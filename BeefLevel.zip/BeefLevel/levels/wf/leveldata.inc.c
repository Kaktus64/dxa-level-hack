#include "levels/wf/area_1/collision.inc.c"
#include "levels/wf/area_1/macro.inc.c"
#include "levels/wf/area_1/spline.inc.c"
#include "levels/wf/model.inc.c"
